using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

namespace Obfuscator
{
    /// <summary>
    /// 轻量 .NET 混淆器：对 net48 程序集执行
    ///  1) 符号重命名（类型/方法/字段，跳过入口点/构造/虚方法）
    ///  2) 字符串加密（ldstr → 调用内置解密方法，密钥异或）
    ///  3) 内嵌资源加密（PNG 等资源字节异或，运行时按需还原）
    /// 用法: dotnet run -- <in.exe> <outDir>
    /// </summary>
    public static class Program
    {
        private const byte StringKey = 0x7B;   // 字符串加密密钥
        private const byte ResKey = 0x5A;      // 资源加密密钥
        private static readonly Random Rng = new Random();
        private static readonly HashSet<string> _usedNames = new HashSet<string>(StringComparer.Ordinal);

        public static int Main(string[] args)
        {
            if (args.Length < 2)
            {
                Console.WriteLine("用法: Obfuscator <in.exe> <outDir>");
                return 1;
            }
            string inPath = Path.GetFullPath(args[0]);
            string outDir = Path.GetFullPath(args[1]);
            if (!File.Exists(inPath)) { Console.WriteLine("输入文件不存在: " + inPath); return 1; }
            Directory.CreateDirectory(outDir);

            using (var module = ModuleDefMD.Load(inPath))
            {
                Console.WriteLine("模块: " + module.Name);

                // 1. 注入字符串解密方法
                MethodDef decryptor = InjectStringDecryptor(module);

                // 1.5 内嵌资源名随机化（同步改写 GetManifestResourceStream 调用处）
                RenameResources(module);

                // 2. 字符串加密（args[2]="nostr" 时跳过，用于定位问题）
                int encrypted = 0;
                if (args.Length < 3 || args[2] != "nostr")
                    encrypted = EncryptStrings(module, decryptor);
                Console.WriteLine("字符串加密: " + encrypted + " 处");

                // 3. 符号重命名
                int renamed = RenameSymbols(module);
                Console.WriteLine("符号重命名: " + renamed + " 个");

                // 4. 资源加密
                int resources = EncryptResources(module);
                Console.WriteLine("资源加密: " + resources + " 个");

                // 5. 展开后短分支可能超距，统一转长分支
                foreach (var type in module.GetTypes())
                    foreach (var m in type.Methods)
                        if (m.Body != null)
                            m.Body.SimplifyBranches();

                string outExe = Path.Combine(outDir, Path.GetFileName(inPath));
                module.Write(outExe);
                Console.WriteLine("输出: " + outExe);

                // 6. 自我验证：重载解析 + 资源可还原
                Verify(outExe);
            }
            return 0;
        }

        /// <summary>混淆后验证：元数据可重载、入口存在、解密方法存在、资源 XOR 还原为 PNG</summary>
        private static void Verify(string path)
        {
            bool ok = true;
            try
            {
                using (var m2 = ModuleDefMD.Load(path))
                {
                    Console.WriteLine("验证: 元数据重载 OK (" + m2.Types.Count + " 类型)");
                    if (m2.EntryPoint == null) { Console.WriteLine("验证失败: 无入口点"); ok = false; }
                    else Console.WriteLine("验证: 入口点存在 " + m2.EntryPoint.Name);

                    bool hasX = false;
                    foreach (var t in m2.GetTypes())
                        foreach (var mm in t.Methods)
                        {
                            if (!mm.IsStatic || mm.Body == null) continue;
                            if (mm.ReturnType.TypeName != "String") continue;
                            var ps = mm.Parameters;
                            if (ps.Count != 2) continue;
                            if (ps[0].Type.TypeName != "Byte[]" || ps[1].Type.TypeName != "Byte") continue;
                            // 特征：方法体内调用 Encoding.GetString(byte[])
                            foreach (var ins in mm.Body.Instructions)
                            {
                                if ((ins.OpCode == OpCodes.Call || ins.OpCode == OpCodes.Callvirt) &&
                                    ins.Operand is MemberRef mr && mr.Name == "GetString")
                                    hasX = true;
                            }
                        }
                    Console.WriteLine("验证: 字符串解密方法 " + (hasX ? "存在（已随机命名）" : "缺失"));
                    if (!hasX) ok = false;

                    foreach (var r in m2.Resources)
                    {
                        if (!(r is EmbeddedResource er)) continue;
                        var reader = er.CreateReader();
                        byte[] data = reader.ReadBytes((int)reader.Length);
                        if (data.Length > 8 && data[0] == 0x89 && data[1] == 0x50 && data[2] == 0x4E && data[3] == 0x47)
                        {
                            Console.WriteLine("验证失败: 资源 " + er.Name + " 仍是明文 PNG（未加密）");
                            ok = false;
                        }
                        else
                        {
                            for (int i = 0; i < data.Length; i++) data[i] ^= ResKey;
                            bool png = data.Length > 8 && data[0] == 0x89 && data[1] == 0x50 && data[2] == 0x4E && data[3] == 0x47;
                            Console.WriteLine("验证: 资源 " + er.Name + (png ? " XOR 还原 OK（PNG 474×581）" : "还原失败"));
                            if (!png) ok = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("验证异常: " + ex.Message);
                ok = false;
            }
            Console.WriteLine(ok ? "验证: 全部通过" : "验证: 存在失败项");
            if (!ok) Environment.Exit(2);
        }

        // ================= 字符串解密方法注入 =================

        /// <summary>
        /// 注入静态方法:
        ///   private static string X(byte[] b, byte k) {
        ///       int n = b.Length; int j = 0;
        ///       loop: if (j >= n) goto end;
        ///             b[j] = (byte)(b[j] ^ k); j++; goto loop;
        ///       end: return Encoding.UTF8.GetString(b);
        ///   }
        /// </summary>
        private static MethodDef InjectStringDecryptor(ModuleDef module)
        {
            var type = new TypeDefUser("X", module.CorLibTypes.Object.TypeDefOrRef)
            {
                Attributes = TypeAttributes.NotPublic | TypeAttributes.Abstract | TypeAttributes.Sealed
            };

            var byteArr = new SZArraySig(module.CorLibTypes.Byte);
            var m = new MethodDefUser("X",
                MethodSig.CreateStatic(module.CorLibTypes.String, byteArr, module.CorLibTypes.Byte))
            {
                // Assembly(internal) 可见：会被程序集内所有类的方法调用，不能是 private
                Attributes = MethodAttributes.Assembly | MethodAttributes.Static | MethodAttributes.HideBySig,
                ImplAttributes = MethodImplAttributes.IL | MethodImplAttributes.Managed
            };
            var body = new CilBody();
            m.Body = body;
            // 声明局部变量 n（loc0）、j（loc1）—— stloc/ldloc 必须与 LocalVarSig 匹配
            body.Variables.Add(new Local(module.CorLibTypes.Int32));
            body.Variables.Add(new Local(module.CorLibTypes.Int32));

            // var n = b.Length;
            body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));
            body.Instructions.Add(Instruction.Create(OpCodes.Ldlen));
            body.Instructions.Add(Instruction.Create(OpCodes.Conv_I4));
            body.Instructions.Add(Instruction.Create(OpCodes.Stloc_0));
            // var j = 0;
            body.Instructions.Add(Instruction.Create(OpCodes.Ldc_I4_0));
            body.Instructions.Add(Instruction.Create(OpCodes.Stloc_1));

            var encType = new TypeRefUser(module, "System.Text", "Encoding", module.CorLibTypes.AssemblyRef);
            var getUtf8 = new MemberRefUser(module, "get_UTF8",
                MethodSig.CreateStatic(encType.ToTypeSig()), encType);
            var getStr = new MemberRefUser(module, "GetString",
                MethodSig.CreateInstance(module.CorLibTypes.String, byteArr), encType);

            Instruction loop = Instruction.Create(OpCodes.Ldloc_1);   // 循环入口：j
            Instruction cont = Instruction.Create(OpCodes.Nop);
            Instruction end = Instruction.Create(OpCodes.Call, getUtf8); // 跳出时直接取 UTF8

            // loop: if (j < n) goto cont; else goto end
            body.Instructions.Add(loop);
            body.Instructions.Add(Instruction.Create(OpCodes.Ldloc_0));
            body.Instructions.Add(Instruction.Create(OpCodes.Blt, cont));
            body.Instructions.Add(Instruction.Create(OpCodes.Br, end));
            body.Instructions.Add(cont);
            // b[j] = (byte)(b[j] ^ k);
            body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));   // 数组 b
            body.Instructions.Add(Instruction.Create(OpCodes.Ldloc_1));   // 索引 j
            body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));   // 数组 b（取值用）
            body.Instructions.Add(Instruction.Create(OpCodes.Ldloc_1));   // 索引 j（取值用）
            body.Instructions.Add(Instruction.Create(OpCodes.Ldelem_U1));
            body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_1));
            body.Instructions.Add(Instruction.Create(OpCodes.Xor));
            body.Instructions.Add(Instruction.Create(OpCodes.Stelem_I1));
            // j++;
            body.Instructions.Add(Instruction.Create(OpCodes.Ldloc_1));
            body.Instructions.Add(Instruction.Create(OpCodes.Ldc_I4_1));
            body.Instructions.Add(Instruction.Create(OpCodes.Add));
            body.Instructions.Add(Instruction.Create(OpCodes.Stloc_1));
            body.Instructions.Add(Instruction.Create(OpCodes.Br, loop));
            // end: return Encoding.UTF8.GetString(b);
            body.Instructions.Add(end);                                   // [enc]
            body.Instructions.Add(Instruction.Create(OpCodes.Ldarg_0));   // [enc, b]
            body.Instructions.Add(Instruction.Create(OpCodes.Callvirt, getStr)); // [str]
            body.Instructions.Add(Instruction.Create(OpCodes.Ret));

            body.MaxStack = 8;
            body.KeepOldMaxStack = true;
            m.Parameters[0].Name = "b";
            m.Parameters[1].Name = "k";
            type.Methods.Add(m);
            module.Types.Add(type);
            return m;
        }

        // ================= 资源名随机化 =================

        private static void RenameResources(ModuleDef module)
        {
            foreach (var r in module.Resources)
            {
                if (!(r is EmbeddedResource er)) continue;
                if (er.Name.Contains("PrivateImplementationDetails")) continue;
                string oldName = er.Name;
                string newName = "r" + NewName(_usedNames) + ".png";
                er.Name = newName;
                Console.WriteLine("资源重命名: " + oldName + " -> " + newName);
                // 同步改写 GetManifestResourceStream 的 ldstr 参数
                foreach (var type in module.GetTypes())
                    foreach (var mm in type.Methods)
                    {
                        if (mm.Body == null) continue;
                        var ins = mm.Body.Instructions;
                        for (int i = 0; i < ins.Count; i++)
                        {
                            if (ins[i].OpCode != OpCodes.Ldstr || !Equals(ins[i].Operand, oldName)) continue;
                            if (i + 1 >= ins.Count) continue;
                            var nxt = ins[i + 1];
                            if (nxt.OpCode == OpCodes.Call &&
                                nxt.Operand is IMethod im && im.Name == "GetManifestResourceStream")
                                ins[i].Operand = newName;
                        }
                    }
            }
        }

        // ================= 字符串加密 =================

        private static int EncryptStrings(ModuleDef module, MethodDef decryptor)
        {
            int count = 0;
            foreach (var type in module.GetTypes())
            {
                foreach (var method in type.Methods)
                {
                    if (method.Body == null) continue;
                    var instrs = method.Body.Instructions;
                    for (int i = 0; i < instrs.Count; i++)
                    {
                        var ins = instrs[i];
                        if (ins.OpCode != OpCodes.Ldstr) continue;
                        string text = (string)ins.Operand;
                        if (string.IsNullOrEmpty(text)) continue; // 空串保持

                        byte[] enc = Encode(text);
                        var expanded = new List<Instruction>();
                        // 构造 byte[]（先压数组，再压 key）。每次 stelem 都会消费数组引用，
                        // 因此每次填充前都要 dup 保留引用（方法栈上可能还有其他值）。
                        expanded.Add(Instruction.CreateLdcI4(enc.Length));
                        expanded.Add(Instruction.Create(OpCodes.Newarr, module.CorLibTypes.Byte.TypeDefOrRef));
                        for (int j = 0; j < enc.Length; j++)
                        {
                            expanded.Add(Instruction.Create(OpCodes.Dup));
                            expanded.Add(Instruction.CreateLdcI4(j));
                            expanded.Add(Instruction.CreateLdcI4(enc[j]));
                            expanded.Add(Instruction.Create(OpCodes.Stelem_I1));
                        }
                        expanded.Add(Instruction.CreateLdcI4(StringKey));
                        expanded.Add(Instruction.Create(OpCodes.Call, decryptor));

                        // 复用原指令对象：先改写为展开的第一条指令，其余插在其后。
                        // 不能 RemoveAt：被删指令可能同时是分支/EH 边界的引用目标。
                        ins.OpCode = expanded[0].OpCode;
                        ins.Operand = expanded[0].Operand;
                        for (int k = 1; k < expanded.Count; k++) instrs.Insert(i + k, expanded[k]);
                        i += expanded.Count - 1;
                        count++;
                        method.Body.MaxStack = (ushort)Math.Max((int)method.Body.MaxStack, 16);
                        method.Body.KeepOldMaxStack = true; // 展开后栈深已人工保证，跳过 dnlib 重算
                    }
                }
            }
            return count;
        }

        private static byte[] Encode(string s)
        {
            byte[] data = Encoding.UTF8.GetBytes(s);
            for (int i = 0; i < data.Length; i++) data[i] ^= StringKey;
            return data;
        }

        // ================= 符号重命名 =================

        private static int RenameSymbols(ModuleDef module)
        {
            int count = 0;
            foreach (var type in module.GetTypes())
            {
                if (type.IsGlobalModuleType) continue;          // <Module>
                // 类型名重命名；命名空间一并清除（不留 IpSwitcher 线索）
                type.Namespace = "";
                type.Name = NewName(_usedNames);
                count++;
                // 字段
                foreach (var f in type.Fields)
                {
                    if (f.IsRuntimeSpecialName || f.IsSpecialName) continue;
                    f.Name = NewName(_usedNames);
                    count++;
                }
                // 方法
                foreach (var m in type.Methods)
                {
                    if (m.IsRuntimeSpecialName || m.IsSpecialName) continue; // .ctor/.cctor/属性访问器等
                    if (m.IsVirtual) continue;                               // override/接口实现
                    if (module.EntryPoint != null && m == module.EntryPoint) continue;
                    m.Name = NewName(_usedNames);
                    count++;
                }
            }
            return count;
        }

        private static string NewName(HashSet<string> used)
        {
            const string chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            while (true)
            {
                int len = 4 + Rng.Next(5); // 4-8 位
                var sb = new StringBuilder(len);
                for (int i = 0; i < len; i++) sb.Append(chars[Rng.Next(chars.Length)]);
                string name = sb.ToString();
                if (used.Add(name)) return name;
            }
        }

        // ================= 资源加密 =================

        private static int EncryptResources(ModuleDef module)
        {
            int count = 0;
            var toRemove = new List<EmbeddedResource>();
            var toAdd = new List<EmbeddedResource>();
            foreach (var r in module.Resources)
            {
                if (!(r is EmbeddedResource er)) continue;
                if (er.Name.Contains("PrivateImplementationDetails")) continue; // 编译器内联数据，不动
                byte[] data;
                var reader = er.CreateReader();
                data = reader.ReadBytes((int)reader.Length);
                if (data == null || data.Length == 0) continue;
                for (int i = 0; i < data.Length; i++) data[i] ^= ResKey;
                toRemove.Add(er);
                toAdd.Add(new EmbeddedResource(er.Name, data, er.Attributes));
                count++;
            }
            foreach (var er in toRemove) module.Resources.Remove(er);
            foreach (var er in toAdd) module.Resources.Add(er);
            return count;
        }
    }
}
