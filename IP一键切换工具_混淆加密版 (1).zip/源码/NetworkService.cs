using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Management;

namespace IpSwitcher
{
    /// <summary>
    /// 网络核心服务：网卡枚举、netsh 设置 IP、WMI 设置 DNS、失败回滚、IP 校验、APIPA 处理。
    /// 所有命令字符串运行时解密，避免明文暴露。
    /// 说明：DNS 使用 WMI SetDNSServerSearchOrder（支持主/备双 DNS），避开 netsh add dnsservers
    /// 对中文接口名的解析 bug；store=persistent 仅用于 set address（set dnsservers 不支持）。
    /// </summary>
    public static class NetworkService
    {
        // ---- 加密命令（StringCipher 运行时还原）----
        private static readonly string CmdNetsh = StringCipher.Decrypt("JxUnBFk=");
        private static readonly string TplSetAddr = StringCipher.Decrypt("IB4nEkMSAgsAUilCRgYWUDYRQxQWATkAClI=");
        private static readonly string TplSetDns = StringCipher.Decrypt("IB4nEkMSAgsAUilCRgYWUDYRQxEcFjgAC1csAiA=");
        private static readonly string ArgName = StringCipher.Decrypt("JxE+Egw=");
        private static readonly string ArgStaticAddr = StringCipher.Decrypt("Oh8mBVIRXhsREzRbUxJXRzcXBgYBWA==");
        private static readonly string ArgMask = StringCipher.Decrypt("aR0yBFpJ");
        private static readonly string ArgGateway = StringCipher.Decrypt("aRcyA1QDAhFY");
        private static readonly string ArgNone = StringCipher.Decrypt("Jx89Eg==");
        private static readonly string ArgGwMetric = StringCipher.Decrypt("aRckGlQAEQEGT3E=");
        private static readonly string ArgSourceDhcp = StringCipher.Decrypt("aQM8AkMXBlUBGiNC");
        private static readonly string ArgStore = StringCipher.Decrypt("aQMnGEMRXhgAADNbQ0ZTTSc=");
        private static readonly string WmiPhysicalAdapter = StringCipher.Decrypt("GRgqBFgXAgQkFiFCRFdE");
        private static readonly string ApipaPrefix = StringCipher.Decrypt("eEZqWQNBV0Y=");
        private static readonly string WmiConfigQuery = StringCipher.Decrypt("GjUfMnIgQ0JFNBJ9fRJhSj1WUSo8AD8SFlMiMTcWQQAGGiYdLlRZVUNRMhEKGhxFHC08cwxQGhlFEREOBBEle15WU1tu");
        private static readonly string WmiSetDnsMethod = StringCipher.Decrypt("GhUnM38nMA0XBCVAY1dXUTANLAcWADk=");
        private static readonly string WmiDnsField = StringCipher.Decrypt("DT4AJFQGFQ0XISVTQlFebCEBBgc=");
        private static readonly string WmiReturnValue = StringCipher.Decrypt("GxUnAkMaNQkJByU=");

        // ---- 网卡信息 ----
        public class AdapterInfo
        {
            public string Name { get; set; }            // 系统显示名（netsh 用）
            public string Description { get; set; }     // 硬件描述
            public string Id { get; set; }              // 接口 GUID
            public int Index { get; set; }              // 接口索引
            public bool IsPhysical { get; set; }
            public bool IsWiredOrWifi { get; set; }     // 以太网 / WiFi（区别于蓝牙、虚拟网卡）
            public bool Up { get; set; }
            public string Ipv4 { get; set; }
            public string Mask { get; set; }
            public string Gateway { get; set; }
            public string Dns { get; set; }
            public bool DhcpEnabled { get; set; }
            public bool IsApipa { get; set; }
            public override string ToString() => Name;
        }

        /// <summary>枚举网卡：物理优先、在线且有 IP 优先、按名称排序</summary>
        public static List<AdapterInfo> GetAdapters()
        {
            var list = new List<AdapterInfo>();
            HashSet<string> physical = GetPhysicalAdapterNames();

            foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Loopback) continue;
                if (ni.NetworkInterfaceType == NetworkInterfaceType.Tunnel) continue;

                // WMI 未识别到物理网卡时，用类型兜底判断
                bool isPhysical = physical.Contains(ni.Name, StringComparer.OrdinalIgnoreCase);
                bool isWiredOrWifi = ni.NetworkInterfaceType == NetworkInterfaceType.Ethernet ||
                                     ni.NetworkInterfaceType == NetworkInterfaceType.Wireless80211;
                if (!isPhysical && isWiredOrWifi) isPhysical = true;

                var info = new AdapterInfo
                {
                    Name = ni.Name,
                    Description = ni.Description,
                    Id = ni.Id,
                    IsPhysical = isPhysical,
                    IsWiredOrWifi = isWiredOrWifi,
                    Up = ni.OperationalStatus == OperationalStatus.Up
                };

                try
                {
                    var props = ni.GetIPProperties();
                    var v4 = props.GetIPv4Properties();
                    if (v4 != null)
                    {
                        info.Index = v4.Index;
                        info.DhcpEnabled = v4.IsDhcpEnabled || v4.IsAutomaticPrivateAddressingActive;
                    }

                    var uni = props.UnicastAddresses.FirstOrDefault(u =>
                        u.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                    if (uni != null)
                    {
                        info.Ipv4 = uni.Address.ToString();
                        if (uni.IPv4Mask != null) info.Mask = uni.IPv4Mask.ToString();
                        info.IsApipa = info.Ipv4.StartsWith(ApipaPrefix, StringComparison.Ordinal);
                    }

                    var gw = props.GatewayAddresses.FirstOrDefault(g =>
                        g.Address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                    if (gw != null) info.Gateway = gw.Address.ToString();

                    var dns = props.DnsAddresses.FirstOrDefault(d =>
                        d.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
                    if (dns != null) info.Dns = dns.ToString();
                }
                catch
                {
                    // 单个适配器读取失败不阻断
                }

                list.Add(info);
            }

            return list
                .OrderByDescending(a => a.IsWiredOrWifi)   // 以太网/WiFi 排最前，蓝牙/虚拟靠后
                .ThenByDescending(a => a.IsPhysical)
                .ThenByDescending(a => a.Up)
                .ThenByDescending(a => !string.IsNullOrEmpty(a.Ipv4))
                .ThenBy(a => a.Name)
                .ToList();
        }

        private static HashSet<string> GetPhysicalAdapterNames()
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            try
            {
                string q = "SELECT Name FROM Win32_NetworkAdapter WHERE " +
                           WmiPhysicalAdapter + "=TRUE AND NetConnectionStatus IS NOT NULL";
                using (var searcher = new ManagementObjectSearcher(q))
                {
                    foreach (ManagementObject mo in searcher.Get())
                    {
                        object name = mo["Name"];
                        if (name != null) set.Add(name.ToString());
                    }
                }
            }
            catch { }
            return set;
        }

        // ---- 应用配置 ----

        /// <summary>当前网卡配置快照（用于回滚）</summary>
        public class Snapshot
        {
            public string AdapterName;
            public int Index;
            public string Ipv4;
            public string Mask;
            public string Gateway;
            public List<string> DnsList;
            public bool Dhcp;
        }

        /// <summary>读取网卡当前配置快照</summary>
        public static Snapshot Capture(AdapterInfo adapter)
        {
            var dnsList = new List<string>();
            try
            {
                foreach (NetworkInterface ni in NetworkInterface.GetAllNetworkInterfaces())
                {
                    if (!string.Equals(ni.Id, adapter.Id, StringComparison.OrdinalIgnoreCase)) continue;
                    var props = ni.GetIPProperties();
                    foreach (var d in props.DnsAddresses)
                    {
                        if (d.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                            dnsList.Add(d.ToString());
                    }
                    break;
                }
            }
            catch { }

            return new Snapshot
            {
                AdapterName = adapter.Name,
                Index = adapter.Index,
                Ipv4 = adapter.Ipv4 ?? "",
                Mask = adapter.Mask ?? "",
                Gateway = adapter.Gateway ?? "",
                DnsList = dnsList,
                Dhcp = adapter.DhcpEnabled
            };
        }

        /// <summary>应用方案（带失败回滚）。返回执行结果文本。</summary>
        public static string Apply(AdapterInfo adapter, Profile profile, Snapshot rollback)
        {
            var log = new StringBuilder();
            bool failed = false;

            Action<string> run = cmd =>
            {
                var r = RunNetsh(cmd);
                if (r.ExitCode != 0 || ContainsError(r.Output)) failed = true;
                if (!string.IsNullOrWhiteSpace(r.Output)) log.Append(r.Output + "\r\n");
            };

            if (profile.Dhcp)
            {
                // IP：DHCP 自动获取
                run(TplSetAddr + " " + ArgName + "=" + Quote(adapter.Name) +
                    " " + ArgSourceDhcp + ArgStore);
                // DNS：DHCP 自动或手动
                if (profile.AutoDns || string.IsNullOrWhiteSpace(profile.Dns1))
                {
                    run(TplSetDns + " " + ArgName + "=" + Quote(adapter.Name) + " " + ArgSourceDhcp);
                }
                else
                {
                    if (!SetDnsViaWmi(adapter, profile.Dns1, profile.Dns2)) failed = true;
                }
            }
            else
            {
                // 静态 IP（set address 支持 store=persistent）
                var sb = TplSetAddr + " " + ArgName + "=" + Quote(adapter.Name) + " " + ArgStaticAddr +
                         profile.Address + ArgMask + profile.Mask;
                if (!string.IsNullOrWhiteSpace(profile.Gateway))
                    sb += ArgGateway + profile.Gateway + ArgGwMetric;
                else
                    sb += ArgGateway + ArgNone + ArgGwMetric;
                sb += ArgStore;
                run(sb);

                // DNS：手动（WMI 双 DNS）或自动
                if (profile.AutoDns || string.IsNullOrWhiteSpace(profile.Dns1))
                {
                    run(TplSetDns + " " + ArgName + "=" + Quote(adapter.Name) + " " + ArgSourceDhcp);
                }
                else
                {
                    if (!SetDnsViaWmi(adapter, profile.Dns1, profile.Dns2)) failed = true;
                }
            }

            // 失败检测 → 回滚
            if (failed && rollback != null)
            {
                log.AppendLine("[检测到错误，自动回滚到切换前配置]");
                log.Append(RestoreSnapshot(adapter, rollback));
            }

            log.AppendLine(failed ? "[FAILED] 应用失败" + (rollback != null ? "，已回滚" : "") : "[OK] 配置已应用");
            return log.ToString();
        }

        /// <summary>
        /// 通过 WMI 设置 DNS（支持主/备双地址）。dns2 为空时仅设主 DNS。
        /// 返回是否成功。
        /// </summary>
        private static bool SetDnsViaWmi(AdapterInfo adapter, string dns1, string dns2)
        {
            try
            {
                var list = new List<string>();
                if (!string.IsNullOrWhiteSpace(dns1)) list.Add(dns1.Trim());
                if (!string.IsNullOrWhiteSpace(dns2)) list.Add(dns2.Trim());
                if (list.Count == 0) list.Add("0.0.0.0"); // 占位避免空数组被拒

                string query = WmiConfigQuery + adapter.Index;
                using (var searcher = new ManagementObjectSearcher(query))
                {
                    foreach (ManagementObject mo in searcher.Get())
                    {
                        var inParams = mo.GetMethodParameters(WmiSetDnsMethod);
                        inParams[WmiDnsField] = list.ToArray();
                        var outParams = mo.InvokeMethod(WmiSetDnsMethod, inParams, null);
                        int ret = Convert.ToInt32(outParams[WmiReturnValue]);
                        return ret == 0;
                    }
                }
                return false;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>回滚到快照（还原 IP/DNS 或 DHCP）</summary>
        public static string RestoreSnapshot(AdapterInfo adapter, Snapshot snap)
        {
            var log = new StringBuilder();
            string ni = Quote(adapter.Name);

            if (snap.Dhcp)
            {
                log.Append(RunNetsh(TplSetAddr + " " + ArgName + "=" + ni + " " + ArgSourceDhcp + ArgStore).Output);
                log.Append(RunNetsh(TplSetDns + " " + ArgName + "=" + ni + " " + ArgSourceDhcp).Output);
            }
            else if (!string.IsNullOrWhiteSpace(snap.Ipv4))
            {
                var sb = TplSetAddr + " " + ArgName + "=" + ni + " " + ArgStaticAddr + snap.Ipv4 +
                         ArgMask + (string.IsNullOrEmpty(snap.Mask) ? "255.255.255.0" : snap.Mask);
                if (!string.IsNullOrWhiteSpace(snap.Gateway))
                    sb += ArgGateway + snap.Gateway + ArgGwMetric;
                else
                    sb += ArgGateway + ArgNone + ArgGwMetric;
                sb += ArgStore;
                log.Append(RunNetsh(sb).Output);

                // 恢复原 DNS
                if (snap.DnsList != null && snap.DnsList.Count > 0)
                {
                    string d1 = snap.DnsList[0];
                    string d2 = snap.DnsList.Count > 1 ? snap.DnsList[1] : "";
                    if (!SetDnsViaWmi(adapter, d1, d2))
                        log.AppendLine("[回滚警告] DNS 恢复失败");
                }
                else
                {
                    log.Append(RunNetsh(TplSetDns + " " + ArgName + "=" + ni + " " + ArgSourceDhcp).Output);
                }
            }
            return log.ToString();
        }

        /// <summary>执行 netsh（隐藏窗口，输出 GBK 解码），返回输出与退出码</summary>
        private static (string Output, int ExitCode) RunNetsh(string args)
        {
            try
            {
                var psi = new ProcessStartInfo(CmdNetsh, args)
                {
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    StandardOutputEncoding = Encoding.GetEncoding(936),
                    StandardErrorEncoding = Encoding.GetEncoding(936)
                };
                using (var p = Process.Start(psi))
                {
                    string stdout = p.StandardOutput.ReadToEnd();
                    string stderr = p.StandardError.ReadToEnd();
                    if (!p.WaitForExit(15000))
                    {
                        try { p.Kill(); } catch { }
                    }
                    string r = (stdout + stderr).Trim();
                    return (r, p.ExitCode);
                }
            }
            catch (Exception ex)
            {
                return ("执行异常: " + ex.Message, -1);
            }
        }

        private static bool ContainsError(string output)
        {
            if (string.IsNullOrWhiteSpace(output)) return false;
            return output.Contains("错误") || output.Contains("失败") ||
                   output.Contains("无法") || output.Contains("提升") ||
                   output.Contains("元素") || output.Contains("拒绝") ||
                   output.Contains("无效") || output.Contains("找不到") ||
                   output.Contains("denied") || output.Contains("elevation") ||
                   output.Contains("not found") || output.Contains("cannot");
        }

        private static string Quote(string name)
        {
            if (name.IndexOf(' ') >= 0) return "\"" + name + "\"";
            return name;
        }

        // ---- IP 校验（对齐参考程序：拒绝无效/网络/广播/注入地址、非连续掩码）----

        public static bool IsValidIpv4(string text)
        {
            if (string.IsNullOrWhiteSpace(text)) return false;
            var parts = text.Split('.');
            if (parts.Length != 4) return false;
            foreach (var p in parts)
            {
                if (!int.TryParse(p, out int v) || v < 0 || v > 255) return false;
            }
            var ip = parts.Select(int.Parse).ToArray();
            if (ip.All(v => v == 0)) return false;
            if (ip.All(v => v == 255)) return false;
            return true;
        }

        /// <summary>校验掩码为连续 1（拒绝 255.0.255.0 这类非连续掩码）</summary>
        public static bool IsValidMask(string text)
        {
            if (!IsValidIpv4(text)) return false;
            uint mask = 0;
            foreach (var part in text.Split('.'))
                mask = (mask << 8) | (uint)int.Parse(part);
            uint inv = ~mask;
            return (inv & (inv + 1)) == 0;
        }

        /// <summary>拒绝网络地址 / 广播地址（用于 IP，掩码已知时）</summary>
        public static bool IsReservedAddress(string ipText, string maskText)
        {
            if (!IsValidIpv4(ipText) || !IsValidIpv4(maskText)) return true;
            uint ip = ToUint(ipText);
            uint mask = ToUint(maskText);
            uint net = ip & mask;
            uint bcast = net | ~mask;
            return ip == net || ip == bcast;
        }

        /// <summary>拒绝 169.254.x.x（APIPA 自动专用地址）作为静态配置</summary>
        public static bool IsApipa(string ipText)
        {
            return ipText != null && ipText.StartsWith(ApipaPrefix, StringComparison.Ordinal);
        }

        private static uint ToUint(string ipText)
        {
            uint v = 0;
            foreach (var part in ipText.Split('.'))
                v = (v << 8) | (uint)int.Parse(part);
            return v;
        }
    }
}
