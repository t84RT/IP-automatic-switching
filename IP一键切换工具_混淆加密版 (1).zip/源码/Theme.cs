using System.Drawing;

namespace IpSwitcher
{
    /// <summary>深色主题配色（参考 QuickIP 风格：Background/Surface/Input/Text/Muted/Accent）</summary>
    public static class Theme
    {
        public static readonly Color Background = Color.FromArgb(30, 31, 36);      // 窗体背景
        public static readonly Color Surface = Color.FromArgb(40, 41, 48);        // 面板背景
        public static readonly Color SurfaceAlt = Color.FromArgb(48, 50, 58);     // 面板内控件背景
        public static readonly Color Input = Color.FromArgb(56, 58, 68);          // 输入框背景
        public static readonly Color Text = Color.FromArgb(232, 232, 236);        // 主文字
        public static readonly Color Muted = Color.FromArgb(140, 145, 158);       // 次要文字
        public static readonly Color Accent = Color.FromArgb(34, 195, 230);       // 强调色（青）
        public static readonly Color AccentDark = Color.FromArgb(22, 150, 180);   // 强调色深
        public static readonly Color Success = Color.FromArgb(76, 195, 138);      // 成功
        public static readonly Color Danger = Color.FromArgb(229, 83, 75);        // 失败/删除
        public static readonly Color Border = Color.FromArgb(72, 74, 86);         // 边框

        public static readonly Font UiFont = new Font("Microsoft YaHei UI", 9F);
        public static readonly Font TitleFont = new Font("Microsoft YaHei UI", 10.5F, FontStyle.Bold);
    }
}
