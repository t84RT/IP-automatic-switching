using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace IpSwitcher
{
    /// <summary>
    /// 打赏支持窗口：从程序集内嵌资源加载二维码图片并展示。
    /// 深色主题样式：标题 + 感谢语 + 圆角卡片 + 关闭按钮。
    /// </summary>
    public class SupportForm : Form
    {
        private const string ResourceName = "IpSwitcher.Resources.support.png";

        public SupportForm()
        {
            Text = "赞赏支持";
            BackColor = Theme.Background;
            Font = Theme.UiFont;
            StartPosition = FormStartPosition.CenterParent;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ClientSize = new Size(516, 764);

            // 标题
            var title = new Label
            {
                Text = "赞赏支持",
                Location = new Point(0, 16), Size = new Size(516, 36),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Microsoft YaHei UI", 14F, FontStyle.Bold),
                ForeColor = Color.FromArgb(120, 220, 235)
            };

            // 副标题 / 感谢语
            var subtitle = new Label
            {
                Text = "如果这个工具帮到了你，请小吴同学喝杯奶茶吧～",
                Location = new Point(20, 56), Size = new Size(476, 24),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Microsoft YaHei UI", 9.5F),
                ForeColor = Theme.Muted
            };

            // 二维码卡片（圆角面板包裹图片）
            var card = new RoundPanel { Location = new Point(15, 92), Size = new Size(486, 600), Radius = 14, BackColor = Theme.Surface };
            var pic = new PictureBox
            {
                Location = new Point(6, 9), Size = new Size(474, 581),
                SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Transparent
            };
            try
            {
                using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(ResourceName))
                {
                    if (stream != null) pic.Image = Image.FromStream(DecryptResource(stream));
                    else title.Text = "未找到内嵌二维码资源";
                }
            }
            catch
            {
                title.Text = "二维码加载失败";
            }
            card.Controls.Add(pic);

            // 底部感谢 + 关闭按钮
            var thanks = new Label
            {
                Text = "开发维护不易，感谢支持 · 打赏自愿，不影响使用",
                Location = new Point(20, 698), Size = new Size(476, 20),
                TextAlign = ContentAlignment.MiddleCenter,
                Font = new Font("Microsoft YaHei UI", 8.5F),
                ForeColor = Theme.Muted
            };

            var btnClose = new RoundButton
            {
                Text = "知道了",
                Location = new Point(213, 722), Size = new Size(90, 32),
                Radius = 9, Fill = Theme.Accent
            };
            btnClose.Click += (s, e) => Close();

            Controls.Add(title);
            Controls.Add(subtitle);
            Controls.Add(card);
            Controls.Add(thanks);
            Controls.Add(btnClose);
        }

        /// <summary>
        /// 资源还原：若内嵌资源已被混淆器加密（0x5A 异或），则还原为原始 PNG 流；
        /// 若本来就是明文 PNG（未混淆编译），原样返回。
        /// </summary>
        private static Stream DecryptResource(Stream input)
        {
            var ms = new MemoryStream();
            input.CopyTo(ms);
            byte[] data = ms.ToArray();
            if (data.Length > 8 && data[0] == 0x89 && data[1] == 0x50 && data[2] == 0x4E && data[3] == 0x47)
                return new MemoryStream(data);
            const byte resKey = 0x5A;
            for (int i = 0; i < data.Length; i++) data[i] ^= resKey;
            return new MemoryStream(data);
        }
    }
}
