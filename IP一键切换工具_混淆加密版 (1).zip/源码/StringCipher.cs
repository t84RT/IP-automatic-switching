using System;
using System.Text;

namespace IpSwitcher
{
    /// <summary>
    /// 内置字符串加密：对关键命令/关键字做 XOR+Base64 加密，
    /// 运行时才解密还原，防止直接反编译看到明文命令。
    /// 配合外部混淆器（ConfuserEx / .NET Reactor / SmartAssembly 等）实现双保险。
    /// </summary>
    internal static class StringCipher
    {
        private const string Key = "IpSw1tcher@2026#SecureKey!";

        public static string Encrypt(string plain)
        {
            byte[] data = Encoding.UTF8.GetBytes(plain);
            byte[] key = Encoding.UTF8.GetBytes(Key);
            for (int i = 0; i < data.Length; i++)
                data[i] = (byte)(data[i] ^ key[i % key.Length]);
            return Convert.ToBase64String(data);
        }

        public static string Decrypt(string cipher)
        {
            byte[] data = Convert.FromBase64String(cipher);
            byte[] key = Encoding.UTF8.GetBytes(Key);
            for (int i = 0; i < data.Length; i++)
                data[i] = (byte)(data[i] ^ key[i % key.Length]);
            return Encoding.UTF8.GetString(data);
        }
    }
}
