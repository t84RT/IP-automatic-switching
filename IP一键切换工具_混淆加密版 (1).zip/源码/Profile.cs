using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace IpSwitcher
{
    /// <summary>一套 IP 配置方案（XML 序列化结构，对齐参考程序）</summary>
    [Serializable]
    public class Profile
    {
        /// <summary>方案名称（唯一）</summary>
        public string Name { get; set; } = string.Empty;

        /// <summary>绑定网卡名称（空 = 不绑定，应用时用当前选中的网卡）</summary>
        public string AdapterName { get; set; } = string.Empty;

        /// <summary>true = DHCP 自动获取；false = 静态 IP</summary>
        public bool Dhcp { get; set; }

        /// <summary>true = DNS 由 DHCP 自动获取；false = 使用下方 Dns1/Dns2</summary>
        public bool AutoDns { get; set; }

        public string Address { get; set; } = string.Empty;
        public string Mask { get; set; } = "255.255.255.0";
        public string Gateway { get; set; } = string.Empty;
        public string Dns1 { get; set; } = string.Empty;
        public string Dns2 { get; set; } = string.Empty;

        /// <summary>编辑区展示文字</summary>
        [XmlIgnore]
        public string Summary
        {
            get
            {
                if (Dhcp)
                    return Name + "（DHCP" + (AutoDns ? "" : "·手动DNS") + "）";
                return Name + "（" + Address + "）";
            }
        }

        public Profile Clone()
        {
            return new Profile
            {
                Name = Name,
                AdapterName = AdapterName,
                Dhcp = Dhcp,
                AutoDns = AutoDns,
                Address = Address,
                Mask = Mask,
                Gateway = Gateway,
                Dns1 = Dns1,
                Dns2 = Dns2
            };
        }

        public override string ToString() => Summary;
    }

    /// <summary>配置文件根对象</summary>
    [Serializable]
    public class Settings
    {
        public List<Profile> Profiles { get; set; } = new List<Profile>();
    }
}
