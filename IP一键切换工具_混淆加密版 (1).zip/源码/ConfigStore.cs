using System;
using System.IO;
using System.Xml.Serialization;

namespace IpSwitcher
{
    /// <summary>
    /// 配置存储：profiles.xml 读写 + 保存前自动备份 backup.xml（对齐参考程序）
    /// </summary>
    public static class ConfigStore
    {
        public static string BaseDir => AppDomain.CurrentDomain.BaseDirectory;
        public static string ConfigPath => Path.Combine(BaseDir, "profiles.xml");
        public static string BackupPath => Path.Combine(BaseDir, "backup.xml");

        private static readonly XmlSerializer Serializer = new XmlSerializer(typeof(Settings));

        public static Settings Load()
        {
            var s = new Settings();
            if (!File.Exists(ConfigPath)) return s;
            try
            {
                using (var fs = File.OpenRead(ConfigPath))
                {
                    var obj = Serializer.Deserialize(fs) as Settings;
                    if (obj != null) s = obj;
                }
                if (s.Profiles == null) s.Profiles = new System.Collections.Generic.List<Profile>();
            }
            catch (Exception ex)
            {
                throw new IOException("读取 profiles.xml 失败：" + ex.Message, ex);
            }
            return s;
        }

        /// <summary>保存配置；保存前将旧文件备份为 backup.xml</summary>
        public static void Save(Settings settings)
        {
            // 先备份旧配置
            if (File.Exists(ConfigPath))
            {
                try { File.Copy(ConfigPath, BackupPath, true); }
                catch { /* 备份失败不阻断保存 */ }
            }

            using (var fs = File.Create(ConfigPath))
            {
                Serializer.Serialize(fs, settings);
            }
        }

        /// <summary>从 backup.xml 恢复（返回恢复出的配置；备份不存在返回 null）</summary>
        public static Settings RestoreBackup()
        {
            if (!File.Exists(BackupPath)) return null;
            try
            {
                using (var fs = File.OpenRead(BackupPath))
                {
                    var obj = Serializer.Deserialize(fs) as Settings;
                    if (obj != null && obj.Profiles != null) return obj;
                }
            }
            catch
            {
                return null;
            }
            return null;
        }
    }
}
