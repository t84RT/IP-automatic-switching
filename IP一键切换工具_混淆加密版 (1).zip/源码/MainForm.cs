using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace IpSwitcher
{
    /// <summary>
    /// 主窗体（深色主题，无遮挡布局）：
    /// 顶栏网卡与状态 / 5 个一键快速切换槽位 / 方案列表与编辑区 / 操作与日志
    /// </summary>
    public class MainForm : Form
    {
        // ---- 顶栏 ----
        private ComboBox cmbAdapter;
        private Label lblCurrent;
        private RoundButton btnRefresh;

        // ---- 快速切换 ----
        private readonly RoundButton[] quickButtons = new RoundButton[5];

        // ---- 方案管理 ----
        private ListBox lstProfiles;
        private TextBox txtName;
        private CheckBox chkDhcp;
        private CheckBox chkAutoDns;
        private TextBox txtIp;
        private TextBox txtMask;
        private TextBox txtGateway;
        private TextBox txtDns1;
        private TextBox txtDns2;
        private ComboBox cmbBind;
        private Label lblTip;

        // ---- 操作 ----
        private RoundButton btnApply;
        private RoundButton btnCapture;
        private RoundButton btnExport;
        private RoundButton btnImport;
        private RoundButton btnRestore;
        private RoundButton btnSupport;
        private RoundButton btnClearLog;
        private RichTextBox rtxLog;

        private List<Profile> _profiles = new List<Profile>();
        private List<NetworkService.AdapterInfo> _adapters = new List<NetworkService.AdapterInfo>();
        private NetworkService.Snapshot _lastSnapshot;

        public MainForm()
        {
            Text = "IP 一键切换工具";
            Font = Theme.UiFont;
            BackColor = Theme.Background;
            ForeColor = Theme.Text;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(900, 700);
            MinimumSize = new Size(880, 680);
            DoubleBuffered = true;

            BuildUi();
            RefreshAdapters();   // 先填充网卡与绑定下拉
            LoadProfiles();      // 再加载方案（触发选中时绑定下拉已就绪）
            AppendLog("程序已启动（管理员权限）。");
        }

        // ==================== 界面构建 ====================
        private void BuildUi()
        {
            // ---- 顶栏：网卡与当前状态 ----
            var top = new RoundPanel { Location = new Point(12, 12), Size = new Size(876, 56) };
            top.Controls.Add(MakeLabel("网卡", 16, 21));
            cmbAdapter = new ComboBox
            {
                Location = new Point(64, 16), Size = new Size(250, 28),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Theme.Input, ForeColor = Theme.Text,
                FlatStyle = FlatStyle.Flat, DrawMode = DrawMode.OwnerDrawFixed,
                DropDownHeight = 240
            };
            cmbAdapter.DrawItem += DrawAdapterItem;
            cmbAdapter.SelectedIndexChanged += (s, e) => UpdateCurrent();

            btnRefresh = new RoundButton { Text = "刷新", Location = new Point(322, 14), Size = new Size(74, 30), Radius = 8, Fill = Theme.SurfaceAlt };
            btnRefresh.Click += (s, e) => RefreshAdapters();

            lblCurrent = new Label
            {
                Location = new Point(406, 21), Size = new Size(458, 20),
                ForeColor = Theme.Muted, TextAlign = ContentAlignment.MiddleLeft
            };

            top.Controls.Add(cmbAdapter);
            top.Controls.Add(btnRefresh);
            top.Controls.Add(lblCurrent);
            Controls.Add(top);

            // ---- 快速切换区 ----
            var quick = new RoundPanel { Location = new Point(12, 76), Size = new Size(876, 96) };
            quick.Controls.Add(MakeLabel("一键快速切换（对应方案列表前 5 项）", 16, 12, Theme.Muted, 10));
            for (int i = 0; i < 5; i++)
            {
                var btn = new RoundButton
                {
                    Name = "quick" + i,
                    Location = new Point(16 + i * 173, 34),
                    Size = new Size(165, 46),
                    Radius = 10,
                    Fill = Theme.Accent,
                    Tag = i,
                    Text = "空槽 " + (i + 1)
                };
                int slot = i;
                btn.Click += (s, e) => QuickApply(slot);
                quickButtons[i] = btn;
                quick.Controls.Add(btn);
            }
            Controls.Add(quick);

            // ---- 方案管理区 ----
            var profilePanel = new RoundPanel { Location = new Point(12, 180), Size = new Size(876, 330) };

            // 左：方案列表
            lstProfiles = new ListBox
            {
                Location = new Point(16, 20), Size = new Size(230, 252),
                BackColor = Theme.Input, ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle,
                ItemHeight = 22,
                IntegralHeight = false
            };
            lstProfiles.SelectedIndexChanged += OnProfileSelected;
            lstProfiles.DoubleClick += (s, e) => { if (lstProfiles.SelectedIndex >= 0) ApplySelected(); };

            var btnNew = new RoundButton { Text = "新建", Location = new Point(16, 286), Size = new Size(72, 30), Radius = 8, Fill = Theme.SurfaceAlt };
            btnNew.Click += (s, e) => ClearEditor();
            var btnDelete = new RoundButton { Text = "删除", Location = new Point(96, 286), Size = new Size(72, 30), Radius = 8, Fill = Theme.Danger };
            btnDelete.Click += (s, e) => DeleteSelected();

            // 右：编辑区（坐标显式排布，杜绝遮挡）
            int ex = 262;
            txtName = MakeField(profilePanel, ex, 16, "方案名称", 280);
            chkDhcp = new CheckBox { Text = "DHCP（自动获取）", Location = new Point(ex + 80, 50), AutoSize = true, ForeColor = Theme.Text };
            chkDhcp.CheckedChanged += (s, e) => OnModeChanged();
            chkAutoDns = new CheckBox { Text = "自动获取 DNS", Location = new Point(ex + 300, 50), AutoSize = true, ForeColor = Theme.Text };
            profilePanel.Controls.Add(chkDhcp);
            profilePanel.Controls.Add(chkAutoDns);

            txtIp = MakeField(profilePanel, ex, 82, "IP 地址", 170);
            txtMask = MakeField(profilePanel, ex + 260, 82, "子网掩码", 170);
            txtGateway = MakeField(profilePanel, ex, 120, "默认网关", 170);
            txtDns1 = MakeField(profilePanel, ex + 260, 120, "首选 DNS", 170);
            txtDns2 = MakeField(profilePanel, ex, 158, "备用 DNS", 170);

            var lblBind = MakeLabel("绑定网卡", ex + 260, 161);
            profilePanel.Controls.Add(lblBind);
            cmbBind = new ComboBox
            {
                Location = new Point(ex + 330, 154), Size = new Size(250, 28),
                DropDownStyle = ComboBoxStyle.DropDownList,
                BackColor = Theme.Input, ForeColor = Theme.Text, FlatStyle = FlatStyle.Flat
            };
            profilePanel.Controls.Add(cmbBind);

            lblTip = new Label
            {
                Location = new Point(ex, 192), Size = new Size(600, 40),
                ForeColor = Theme.Muted,
                Text = "提示：保存后自动成为快速切换按钮；双击列表项可直接应用；应用失败会自动回滚。"
            };
            profilePanel.Controls.Add(lblTip);

            var btnSave = new RoundButton { Text = "保存方案", Location = new Point(ex, 236), Size = new Size(100, 34), Radius = 9 };
            btnSave.Click += (s, e) => SaveProfileFromEditor();
            profilePanel.Controls.Add(btnSave);

            profilePanel.Controls.Add(lstProfiles);
            profilePanel.Controls.Add(btnNew);
            profilePanel.Controls.Add(btnDelete);
            Controls.Add(profilePanel);

            // ---- 操作与日志区 ----
            var opPanel = new RoundPanel { Location = new Point(12, 518), Size = new Size(876, 170) };
            btnApply = new RoundButton { Text = "应用选中方案", Location = new Point(16, 20), Size = new Size(130, 36), Radius = 9 };
            btnApply.Click += (s, e) => ApplySelected();
            btnCapture = new RoundButton { Text = "记录当前配置", Location = new Point(156, 20), Size = new Size(120, 36), Radius = 9, Fill = Theme.SurfaceAlt };
            btnCapture.Click += (s, e) => CaptureCurrent();
            btnExport = new RoundButton { Text = "导出…", Location = new Point(286, 20), Size = new Size(80, 36), Radius = 9, Fill = Theme.SurfaceAlt };
            btnExport.Click += (s, e) => ExportConfig();
            btnImport = new RoundButton { Text = "导入…", Location = new Point(376, 20), Size = new Size(80, 36), Radius = 9, Fill = Theme.SurfaceAlt };
            btnImport.Click += (s, e) => ImportConfig();
            btnRestore = new RoundButton { Text = "恢复备份", Location = new Point(466, 20), Size = new Size(90, 36), Radius = 9, Fill = Theme.SurfaceAlt };
            btnRestore.Click += (s, e) => RestoreBackup();
            btnSupport = new RoundButton { Text = "请喝奶茶", Location = new Point(566, 20), Size = new Size(80, 36), Radius = 9, Fill = Theme.AccentDark };
            btnSupport.Click += (s, e) => new SupportForm().ShowDialog(this);
            btnClearLog = new RoundButton { Text = "清空日志", Location = new Point(804, 20), Size = new Size(56, 36), Radius = 9, Fill = Theme.SurfaceAlt };
            btnClearLog.Click += (s, e) => rtxLog.Clear();

            rtxLog = new RichTextBox
            {
                Location = new Point(16, 66), Size = new Size(844, 92),
                ReadOnly = true, BackColor = Color.FromArgb(24, 25, 30),
                ForeColor = Color.FromArgb(210, 214, 220),
                BorderStyle = BorderStyle.None, Font = new Font("Consolas", 9F)
            };

            opPanel.Controls.Add(btnApply);
            opPanel.Controls.Add(btnCapture);
            opPanel.Controls.Add(btnExport);
            opPanel.Controls.Add(btnImport);
            opPanel.Controls.Add(btnRestore);
            opPanel.Controls.Add(btnSupport);
            opPanel.Controls.Add(btnClearLog);
            opPanel.Controls.Add(rtxLog);
            Controls.Add(opPanel);
        }

        // ---- 控件工厂 ----
        private Label MakeLabel(string text, int x, int y, Color? color = null, float size = 9F)
        {
            return new Label
            {
                Text = text, Location = new Point(x, y), AutoSize = true,
                ForeColor = color ?? Theme.Text, Font = new Font("Microsoft YaHei UI", size)
            };
        }

        private TextBox MakeField(Control parent, int x, int y, string label, int width)
        {
            parent.Controls.Add(MakeLabel(label, x, y + 3));
            var tb = new TextBox
            {
                Location = new Point(x + 74, y), Width = width,
                BackColor = Theme.Input, ForeColor = Theme.Text,
                BorderStyle = BorderStyle.FixedSingle
            };
            parent.Controls.Add(tb);
            return tb;
        }

        // ---- 网卡下拉绘制（深色主题）----
        private static string AdapterDisplayName(NetworkService.AdapterInfo a)
        {
            if (a.IsWiredOrWifi) return a.Name + "（物理）";
            if (a.IsPhysical) return a.Name + "（蓝牙/其他）";
            return a.Name + "（虚拟）";
        }

        private void DrawAdapterItem(object sender, DrawItemEventArgs e)
        {
            e.DrawBackground();
            if (e.Index < 0 || e.Index >= _adapters.Count) return;
            var a = _adapters[e.Index];
            string text = AdapterDisplayName(a);
            using (var b = new SolidBrush((e.State & DrawItemState.Selected) != 0 ? Theme.AccentDark : Theme.Input))
            {
                e.Graphics.FillRectangle(b, e.Bounds);
            }
            Color c = a.IsWiredOrWifi ? Theme.Text : Theme.Muted;
            if (a.IsApipa) c = Theme.Danger;
            using (var b = new SolidBrush(c))
            {
                e.Graphics.DrawString(text, e.Font ?? Font, b, e.Bounds.Left + 4, e.Bounds.Top + 2);
            }
            e.DrawFocusRectangle();
        }

        // ==================== 数据 ====================
        private void RefreshAdapters()
        {
            var prevName = cmbAdapter.SelectedIndex >= 0 && cmbAdapter.SelectedIndex < _adapters.Count
                ? _adapters[cmbAdapter.SelectedIndex].Name : null;

            _adapters = NetworkService.GetAdapters();
            cmbAdapter.BeginUpdate();
            cmbAdapter.Items.Clear();
            foreach (var a in _adapters) cmbAdapter.Items.Add(AdapterDisplayName(a));
            cmbAdapter.EndUpdate();

            if (prevName != null)
            {
                int idx = _adapters.FindIndex(a => a.Name == prevName);
                if (idx >= 0) cmbAdapter.SelectedIndex = idx;
                else if (_adapters.Count > 0) cmbAdapter.SelectedIndex = 0;
            }
            else if (_adapters.Count > 0) cmbAdapter.SelectedIndex = 0;

            UpdateBindCombo();
            UpdateCurrent();
        }

        private void UpdateBindCombo()
        {
            var prev = cmbBind.SelectedIndex >= 0 ? cmbBind.Items[cmbBind.SelectedIndex].ToString() : null;
            cmbBind.Items.Clear();
            cmbBind.Items.Add("（跟随当前选中网卡）");
            foreach (var a in _adapters) cmbBind.Items.Add(a.Name);
            if (prev != null && cmbBind.Items.Contains(prev)) cmbBind.SelectedItem = prev;
            else cmbBind.SelectedIndex = 0;
        }

        private void UpdateCurrent()
        {
            var a = CurrentAdapter();
            if (a == null) { lblCurrent.Text = "未选择网卡"; return; }
            string type = a.DhcpEnabled ? "DHCP" : "静态";
            if (a.IsApipa) type = "APIPA(临时)";
            string dns = string.IsNullOrEmpty(a.Dns) ? "无" : a.Dns;
            lblCurrent.Text = "当前: " + (string.IsNullOrEmpty(a.Ipv4) ? "无 IP" : a.Ipv4) +
                              " · " + type + " · DNS " + dns;
        }

        private NetworkService.AdapterInfo CurrentAdapter()
        {
            int idx = cmbAdapter.SelectedIndex;
            if (idx < 0 || idx >= _adapters.Count) return null;
            return _adapters[idx];
        }

        // ---- 方案 ----
        private void LoadProfiles()
        {
            try
            {
                _profiles = ConfigStore.Load().Profiles;
            }
            catch (Exception ex)
            {
                AppendLog("读取配置失败：" + ex.Message);
                _profiles = new List<Profile>();
            }

            if (_profiles.Count == 0)
            {
                _profiles.Add(new Profile { Name = "办公网络-静态IP", Address = "192.168.1.100", Mask = "255.255.255.0", Gateway = "192.168.1.1", Dns1 = "192.168.1.1", Dns2 = "114.114.114.114" });
                _profiles.Add(new Profile { Name = "家庭网络-DHCP", Dhcp = true, AutoDns = true });
            }
            ReloadList();
        }

        private void ReloadList()
        {
            lstProfiles.BeginUpdate();
            lstProfiles.Items.Clear();
            foreach (var p in _profiles) lstProfiles.Items.Add(p);
            lstProfiles.EndUpdate();
            UpdateQuickButtons();
            if (lstProfiles.Items.Count > 0 && lstProfiles.SelectedIndex < 0)
                lstProfiles.SelectedIndex = 0;
        }

        private void UpdateQuickButtons()
        {
            for (int i = 0; i < 5; i++)
            {
                var btn = quickButtons[i];
                if (i < _profiles.Count)
                {
                    var p = _profiles[i];
                    btn.Enabled = true;
                    btn.Text = p.Summary.Length > 10 ? p.Summary.Substring(0, 10) + "…" : p.Summary;
                    btn.Fill = p.Dhcp ? Theme.Success : Theme.Accent;
                }
                else
                {
                    btn.Enabled = false;
                    btn.Text = "空槽 " + (i + 1);
                    btn.Fill = Theme.SurfaceAlt;
                }
            }
        }

        private void OnProfileSelected(object sender, EventArgs e)
        {
            var p = SelectedProfile();
            if (p == null) return;
            txtName.Text = p.Name;
            chkDhcp.Checked = p.Dhcp;
            chkAutoDns.Checked = p.AutoDns;
            txtIp.Text = p.Address;
            txtMask.Text = p.Mask;
            txtGateway.Text = p.Gateway;
            txtDns1.Text = p.Dns1;
            txtDns2.Text = p.Dns2;
            OnModeChanged();
            if (!string.IsNullOrEmpty(p.AdapterName))
            {
                int idx = cmbBind.Items.IndexOf(p.AdapterName);
                cmbBind.SelectedIndex = idx >= 0 ? idx : 0;
            }
            else cmbBind.SelectedIndex = 0;
        }

        private Profile SelectedProfile()
        {
            int idx = lstProfiles.SelectedIndex;
            if (idx < 0 || idx >= _profiles.Count) return null;
            return _profiles[idx];
        }

        private void OnModeChanged()
        {
            bool dhcp = chkDhcp.Checked;
            txtIp.Enabled = !dhcp;
            txtMask.Enabled = !dhcp;
            txtGateway.Enabled = !dhcp;
            if (dhcp) chkAutoDns.Checked = true;
        }

        private void ClearEditor()
        {
            lstProfiles.ClearSelected();
            txtName.Text = "";
            chkDhcp.Checked = false;
            txtIp.Text = "";
            txtMask.Text = "255.255.255.0";
            txtGateway.Text = "";
            txtDns1.Text = "";
            txtDns2.Text = "";
            cmbBind.SelectedIndex = 0;
            txtName.Focus();
        }

        private void DeleteSelected()
        {
            var p = SelectedProfile();
            if (p == null) { AppendLog("请先选择要删除的方案。"); return; }
            _profiles.Remove(p);
            ReloadList();
            SaveToDisk();
            ClearEditor();
            AppendLog("已删除方案：" + p.Name);
        }

        private Profile ReadEditor()
        {
            var p = new Profile
            {
                Name = txtName.Text.Trim(),
                Dhcp = chkDhcp.Checked,
                AutoDns = chkAutoDns.Checked,
                Address = txtIp.Text.Trim(),
                Mask = txtMask.Text.Trim(),
                Gateway = txtGateway.Text.Trim(),
                Dns1 = txtDns1.Text.Trim(),
                Dns2 = txtDns2.Text.Trim()
            };
            if (cmbBind.SelectedIndex > 0) p.AdapterName = cmbBind.SelectedItem.ToString();
            else p.AdapterName = "";
            return p;
        }

        private void SaveProfileFromEditor()
        {
            var p = ReadEditor();
            if (string.IsNullOrWhiteSpace(p.Name)) { AppendLog("请填写方案名称。"); return; }

            string err = ValidateProfile(p);
            if (err != null) { AppendLog("校验失败：" + err); return; }

            int idx = _profiles.FindIndex(x => x.Name == p.Name);
            if (idx >= 0)
            {
                _profiles[idx] = p;
                AppendLog("已更新方案：" + p.Name);
            }
            else
            {
                _profiles.Add(p);
                AppendLog("已新增方案：" + p.Name);
            }
            ReloadList();
            SaveToDisk();
            int sel = _profiles.FindIndex(x => x.Name == p.Name);
            if (sel >= 0) lstProfiles.SelectedIndex = sel;
        }

        private static string ValidateProfile(Profile p)
        {
            if (p.Dhcp) return null;
            if (!NetworkService.IsValidIpv4(p.Address)) return "IP 地址无效";
            if (NetworkService.IsApipa(p.Address)) return "不能使用 169.254.x.x 临时地址";
            if (!NetworkService.IsValidMask(p.Mask)) return "子网掩码无效（需为连续 1）";
            if (NetworkService.IsReservedAddress(p.Address, p.Mask)) return "IP 为网络/广播地址，不能使用";
            if (!string.IsNullOrWhiteSpace(p.Gateway) && !NetworkService.IsValidIpv4(p.Gateway)) return "网关格式无效";
            if (!string.IsNullOrWhiteSpace(p.Dns1) && !NetworkService.IsValidIpv4(p.Dns1)) return "首选 DNS 格式无效";
            if (!string.IsNullOrWhiteSpace(p.Dns2) && !NetworkService.IsValidIpv4(p.Dns2)) return "备用 DNS 格式无效";
            return null;
        }

        private void SaveToDisk()
        {
            try { ConfigStore.Save(new Settings { Profiles = _profiles }); }
            catch (Exception ex) { AppendLog("保存失败：" + ex.Message); }
        }

        // ==================== 应用 ====================
        private void QuickApply(int slot)
        {
            if (slot >= _profiles.Count) return;
            ApplyProfile(_profiles[slot]);
        }

        private void ApplySelected()
        {
            var p = SelectedProfile();
            if (p == null) { AppendLog("请先选择要应用的方案（或点击上方快速切换按钮）。"); return; }
            ApplyProfile(p);
        }

        private void ApplyProfile(Profile p)
        {
            var adapter = ResolveAdapter(p);
            if (adapter == null)
            {
                AppendLog("方案【" + p.Name + "】绑定的网卡不可用，请选择其他网卡。");
                return;
            }

            AppendLog("==========================================");
            AppendLog("切换：网卡【" + adapter.Name + "】→ 方案【" + p.Name + "】");

            _lastSnapshot = NetworkService.Capture(adapter);
            string result = NetworkService.Apply(adapter, p, _lastSnapshot);
            AppendLog(result.Trim());

            var timer = new Timer { Interval = 2500 };
            timer.Tick += (s, e) =>
            {
                timer.Stop();
                RefreshAdapters();
                AppendLog("已刷新网卡状态。");
            };
            timer.Start();
        }

        private NetworkService.AdapterInfo ResolveAdapter(Profile p)
        {
            if (!string.IsNullOrEmpty(p.AdapterName))
            {
                var hit = _adapters.FirstOrDefault(a => a.Name == p.AdapterName);
                if (hit != null)
                {
                    int idx = _adapters.FindIndex(a => a.Name == p.AdapterName);
                    if (idx >= 0 && cmbAdapter.SelectedIndex != idx) cmbAdapter.SelectedIndex = idx;
                    return hit;
                }
                return null;
            }
            return CurrentAdapter();
        }

        private void CaptureCurrent()
        {
            var a = CurrentAdapter();
            if (a == null) { AppendLog("没有可记录的网卡。"); return; }

            var p = new Profile
            {
                Name = "当前配置-" + DateTime.Now.ToString("HHmmss"),
                Dhcp = a.DhcpEnabled && !a.IsApipa,
                AutoDns = string.IsNullOrEmpty(a.Dns),
                Address = a.Ipv4 ?? "",
                Mask = string.IsNullOrEmpty(a.Mask) ? "255.255.255.0" : a.Mask,
                Gateway = a.Gateway ?? "",
                Dns1 = a.Dns ?? "",
                Dns2 = ""
            };
            _profiles.Add(p);
            ReloadList();
            SaveToDisk();
            lstProfiles.SelectedIndex = _profiles.Count - 1;
            AppendLog("已记录当前配置为方案：" + p.Name);
        }

        // ---- 导出 / 导入 / 备份 ----
        private void ExportConfig()
        {
            using (var dlg = new SaveFileDialog { Filter = "XML 配置|*.xml", FileName = "profiles.xml" })
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        File.Copy(ConfigStore.ConfigPath, dlg.FileName, true);
                        AppendLog("已导出配置到：" + dlg.FileName);
                    }
                    catch (Exception ex) { AppendLog("导出失败：" + ex.Message); }
                }
            }
        }

        private void ImportConfig()
        {
            using (var dlg = new OpenFileDialog { Filter = "XML 配置|*.xml", FileName = "profiles.xml" })
            {
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        var loaded = new Settings();
                        using (var fs = File.OpenRead(dlg.FileName))
                        {
                            var obj = new System.Xml.Serialization.XmlSerializer(typeof(Settings)).Deserialize(fs) as Settings;
                            if (obj != null && obj.Profiles != null) loaded = obj;
                        }
                        // 导入前先备份当前配置（防误导入覆盖）
                        if (File.Exists(ConfigStore.ConfigPath))
                            File.Copy(ConfigStore.ConfigPath, ConfigStore.BackupPath, true);
                        _profiles = loaded.Profiles;
                        ReloadList();
                        SaveToDisk();
                        AppendLog("已导入配置：" + dlg.FileName + "（共 " + _profiles.Count + " 个方案）");
                    }
                    catch (Exception ex) { AppendLog("导入失败：" + ex.Message); }
                }
            }
        }

        private void RestoreBackup()
        {
            var s = ConfigStore.RestoreBackup();
            if (s == null || s.Profiles == null || s.Profiles.Count == 0)
            {
                AppendLog("没有可用的备份（backup.xml 不存在或已损坏）。");
                return;
            }
            _profiles = s.Profiles;
            ReloadList();
            SaveToDisk();
            AppendLog("已从备份恢复 " + _profiles.Count + " 个方案。");
        }

        // ---- 日志 ----
        private void AppendLog(string text)
        {
            if (rtxLog == null) return;
            string line = DateTime.Now.ToString("HH:mm:ss") + "  " + text + "\r\n";
            rtxLog.AppendText(line);
            rtxLog.ScrollToCaret();
        }
    }
}
